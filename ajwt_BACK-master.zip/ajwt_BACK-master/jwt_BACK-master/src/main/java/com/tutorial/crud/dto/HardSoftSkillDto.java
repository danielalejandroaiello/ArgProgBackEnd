package com.tutorial.crud.dto;

import javax.validation.constraints.NotBlank;

public class HardSoftSkillDto {

    @NotBlank
    private String habilidad;

    @NotBlank
    private String nivel;

    public HardSoftSkillDto() {
    }

    public HardSoftSkillDto(String habilidad, String nivel) {
        this.habilidad = habilidad;
        this.nivel = nivel;
    }

    public String getHabilidad() {
        return habilidad;
    }

    public void setHabilidad(String habilidad) {
        this.habilidad = habilidad;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }
}
