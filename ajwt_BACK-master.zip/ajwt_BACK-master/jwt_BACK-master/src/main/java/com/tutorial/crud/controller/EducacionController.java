package com.tutorial.crud.controller;

import com.tutorial.crud.dto.EducacionDto;
import com.tutorial.crud.dto.ExperienciaDto;
import com.tutorial.crud.dto.Mensaje;
import com.tutorial.crud.entity.Educacion;
import com.tutorial.crud.entity.Experiencia;
import com.tutorial.crud.service.EducacionService;
import com.tutorial.crud.service.ExperienciaService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/educacion")
@CrossOrigin(origins = "*")
public class EducacionController {


    @Autowired
    EducacionService educacionService;


    @GetMapping("/lista-educacion")
    public ResponseEntity<List<Educacion>> list(){
        List<Educacion> list = educacionService.list();
        return new ResponseEntity(list, HttpStatus.OK);
    }

    @GetMapping("/detail-educacion/{id}")
    public ResponseEntity<Educacion> getById(@PathVariable("id") int id){
        if(!educacionService.existsById(id))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        Educacion educacion = educacionService.getOne(id).get();
        return new ResponseEntity(educacion, HttpStatus.OK);
    }

    @GetMapping("/detailname-educacion/{titulo}")
    public ResponseEntity<Educacion> getByTitulo(@PathVariable("titulo") String titulo){
        if(!educacionService.existsByTitulo(titulo))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        Educacion educacion = educacionService.getByTitulo(titulo).get();
        return new ResponseEntity(educacion, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/create-educacion")
    public ResponseEntity<?> create(@RequestBody EducacionDto educacionDto){

        if(StringUtils.isBlank(educacionDto.getTitulo()))
            return new ResponseEntity(new Mensaje("el Titulo es obligatorio"), HttpStatus.BAD_REQUEST);

        if(educacionService.existsByTitulo(educacionDto.getTitulo()))
            return new ResponseEntity(new Mensaje("ese titulo ya existe"), HttpStatus.BAD_REQUEST);

        //Instituto
        if(StringUtils.isBlank(educacionDto.getInstituto()))
            return new ResponseEntity(new Mensaje("el Instituto es obligatorio"), HttpStatus.BAD_REQUEST);

        if(educacionService.existsByTitulo(educacionDto.getInstituto()))
            return new ResponseEntity(new Mensaje("ese Instituto ya existe"), HttpStatus.BAD_REQUEST);

        //FechaInicioFin
        if(StringUtils.isBlank(educacionDto.getFechaInicioFin()))
            return new ResponseEntity(new Mensaje("la FechaInicioFin es obligatorio"), HttpStatus.BAD_REQUEST);

        if(educacionService.existsByTitulo(educacionDto.getFechaInicioFin()))
            return new ResponseEntity(new Mensaje("la FechaInicioFin ya existe"), HttpStatus.BAD_REQUEST);

        //Descripcion
        if(StringUtils.isBlank(educacionDto.getDescripcion()))
            return new ResponseEntity(new Mensaje("La Descripcion es obligatorio"), HttpStatus.BAD_REQUEST);

        if(educacionService.existsByTitulo(educacionDto.getDescripcion()))
            return new ResponseEntity(new Mensaje("la Descripcion ya existe"), HttpStatus.BAD_REQUEST);


        //tomo el dato del constructor de la clase entity Experiencia
        Educacion educacion = new Educacion(educacionDto.getTitulo(),educacionDto.getInstituto(),educacionDto.getFechaInicioFin(),educacionDto.getDescripcion());

        educacionService.save(educacion);

        return new ResponseEntity(new Mensaje("educacion creada"), HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/update-educacion/{id}")
    public ResponseEntity<?> update(@PathVariable("id")int id, @RequestBody EducacionDto educacionDto){
        if(!educacionService.existsById(id))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);

        if(educacionService.existsByTitulo(educacionDto.getTitulo()) && educacionService.getByTitulo(educacionDto.getTitulo()).get().getId() != id)
            return new ResponseEntity(new Mensaje("es Titulo ya existe"), HttpStatus.BAD_REQUEST);

        if(StringUtils.isBlank(educacionDto.getTitulo()))
            return new ResponseEntity(new Mensaje("el Titulo es obligatorio"), HttpStatus.BAD_REQUEST);

        //falta validar instituto FechaInicioFin y Descripcion

        Educacion educacion = educacionService.getOne(id).get();

        educacion.setTitulo(educacionDto.getTitulo());

        educacion.setInstituto(educacionDto.getInstituto());

        educacion.setFechaInicioFin(educacionDto.getFechaInicioFin());

        educacion.setDescripcion(educacionDto.getDescripcion());


        educacionService.save(educacion);

        return new ResponseEntity(new Mensaje("educacion actualizada"), HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/delete-educacion/{id}")
    public ResponseEntity<?> delete(@PathVariable("id")int id){
        if(!educacionService.existsById(id))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        educacionService.delete(id);
        return new ResponseEntity(new Mensaje("educacion eliminada"), HttpStatus.OK);
    }



}
