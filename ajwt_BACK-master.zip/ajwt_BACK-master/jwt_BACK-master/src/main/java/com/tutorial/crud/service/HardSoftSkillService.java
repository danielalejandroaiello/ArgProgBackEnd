package com.tutorial.crud.service;

import com.tutorial.crud.entity.HardSoftSkill;
import com.tutorial.crud.repository.HardSoftSkillRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class HardSoftSkillService {

    @Autowired
    HardSoftSkillRepository hardSoftSkillRepository;

    public List<HardSoftSkill> list(){

        return hardSoftSkillRepository.findAll();

    }

    public Optional<HardSoftSkill> getOne(int id){

        return hardSoftSkillRepository.findById(id);

    }

    public Optional<HardSoftSkill> getByHabilidad(String habilidad){

        return hardSoftSkillRepository.findByHabilidad(habilidad);

    }

    public void save(HardSoftSkill hardsoftskill){

        hardSoftSkillRepository.save(hardsoftskill);

    }

    public void delete(int id){

        hardSoftSkillRepository.deleteById(id);

    }

    public boolean existsById(int id){

        return hardSoftSkillRepository.existsById(id);

    }

    public boolean existsByHabilidad(String habilidad){

        return hardSoftSkillRepository.existsByHabilidad(habilidad);

    }


}
