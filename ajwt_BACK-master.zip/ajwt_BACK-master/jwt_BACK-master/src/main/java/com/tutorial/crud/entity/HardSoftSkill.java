package com.tutorial.crud.entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Entity;

@Entity
public class HardSoftSkill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private String habilidad;
    private String nivel;

    public HardSoftSkill() {
    }

    public HardSoftSkill(String habilidad, String nivel) {
        this.habilidad = habilidad;
        this.nivel = nivel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getHabilidad() {
        return habilidad;
    }

    public void setHabilidad(String habilidad) {
        this.habilidad = habilidad;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }
}
