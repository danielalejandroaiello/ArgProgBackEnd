package com.tutorial.crud.security.enums;

public enum RolNombre {
    ROLE_ADMIN, ROLE_USER
}
