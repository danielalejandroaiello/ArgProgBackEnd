package com.tutorial.crud.controller;


import com.tutorial.crud.dto.HardSoftSkillDto;
import com.tutorial.crud.dto.Mensaje;
import com.tutorial.crud.entity.HardSoftSkill;
import com.tutorial.crud.service.HardSoftSkillService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hardsoftskill")
@CrossOrigin(origins = "*")
public class HardSoftSkillController {


    @Autowired
    HardSoftSkillService hardsoftskillService;

    @GetMapping("/lista-hardsoftskill")
    public ResponseEntity<List<HardSoftSkill>> list(){
        List<HardSoftSkill> list = hardsoftskillService.list();
        return new ResponseEntity(list, HttpStatus.OK);
    }

    @GetMapping("/detail-hardsoftskill/{id}")
    public ResponseEntity<HardSoftSkill> getById(@PathVariable("id") int id){
        if(!hardsoftskillService.existsById(id))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        HardSoftSkill hardsoftskill = hardsoftskillService.getOne(id).get();
        return new ResponseEntity(hardsoftskill, HttpStatus.OK);
    }

    @GetMapping("/detailname-hardsoftskill/{habilidad}")
    public ResponseEntity<HardSoftSkill> getByHabilidad(@PathVariable("habilidad") String habilidad){
        if(!hardsoftskillService.existsByHabilidad(habilidad))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        HardSoftSkill hardsoftskill = hardsoftskillService.getByHabilidad(habilidad).get();
        return new ResponseEntity(hardsoftskill, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/create-hardsoftskill")
    public ResponseEntity<?> create(@RequestBody HardSoftSkillDto hardsoftskillDto){

        if(StringUtils.isBlank(hardsoftskillDto.getHabilidad()))
            return new ResponseEntity(new Mensaje("la habilidad es obligatorio"), HttpStatus.BAD_REQUEST);

        if(hardsoftskillService.existsByHabilidad(hardsoftskillDto.getHabilidad()))
            return new ResponseEntity(new Mensaje("esa habilidad ya existe"), HttpStatus.BAD_REQUEST);

        //buscar el existBy Nivel

        if(StringUtils.isBlank(hardsoftskillDto.getNivel()))
            return new ResponseEntity(new Mensaje("el nivel es obligatorio"), HttpStatus.BAD_REQUEST);

        if(hardsoftskillService.existsByHabilidad(hardsoftskillDto.getNivel()))
            return new ResponseEntity(new Mensaje("el Nivel ya existe"), HttpStatus.BAD_REQUEST);


        //tomo el dato del constructor de la clase entity Experiencia
        HardSoftSkill hardsoftskill = new HardSoftSkill(hardsoftskillDto.getHabilidad(),hardsoftskillDto.getNivel());

        hardsoftskillService.save(hardsoftskill);

        return new ResponseEntity(new Mensaje("hardsoftskill creado"), HttpStatus.OK);
    }


    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/update-hardsoftskill/{id}")
    public ResponseEntity<?> update(@PathVariable("id")int id, @RequestBody HardSoftSkillDto hardsoftskillDto){
        if(!hardsoftskillService.existsById(id))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);

        if(hardsoftskillService.existsByHabilidad(hardsoftskillDto.getHabilidad()) && hardsoftskillService.getByHabilidad(hardsoftskillDto.getHabilidad()).get().getId() != id)
            return new ResponseEntity(new Mensaje("esa habilidad ya existe"), HttpStatus.BAD_REQUEST);

        if(StringUtils.isBlank(hardsoftskillDto.getHabilidad()))
            return new ResponseEntity(new Mensaje("la habilidad es obligatorio"), HttpStatus.BAD_REQUEST);

        //falta validar PUESTO Y DESCRIPCION

        HardSoftSkill hardsoftskill = hardsoftskillService.getOne(id).get();

        hardsoftskill.setHabilidad(hardsoftskillDto.getHabilidad());

        hardsoftskill.setNivel(hardsoftskillDto.getNivel());


        hardsoftskillService.save(hardsoftskill);

        return new ResponseEntity(new Mensaje("hardsoftskill actualizado"), HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/delete-hardsoftskill/{id}")
    public ResponseEntity<?> delete(@PathVariable("id")int id){
        if(!hardsoftskillService.existsById(id))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        hardsoftskillService.delete(id);
        return new ResponseEntity(new Mensaje("hard soft skill eliminado"), HttpStatus.OK);
    }



}
