package com.tutorial.crud.controller;



import com.tutorial.crud.dto.Mensaje;
import com.tutorial.crud.dto.ProyectoDto;

import com.tutorial.crud.entity.Proyecto;

import com.tutorial.crud.service.ProyectoService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/proyecto")
@CrossOrigin(origins = "*")
public class ProyectoController {

    @Autowired
    ProyectoService proyectoService;


    @GetMapping("/lista-proyecto")
    public ResponseEntity<List<Proyecto>> list(){
        List<Proyecto> list = proyectoService.list();
        return new ResponseEntity(list, HttpStatus.OK);
    }

    @GetMapping("/detail-proyecto/{id}")
    public ResponseEntity<Proyecto> getById(@PathVariable("id") int id){
        if(!proyectoService.existsById(id))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        Proyecto proyecto = proyectoService.getOne(id).get();
        return new ResponseEntity(proyecto, HttpStatus.OK);
    }

    @GetMapping("/detailname-proyecto/{nombre}")
    public ResponseEntity<Proyecto> getByNombre(@PathVariable("nombre") String nombre){
        if(!proyectoService.existsByNombre(nombre))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        Proyecto proyecto = proyectoService.getByNombre(nombre).get();
        return new ResponseEntity(proyecto, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/create-proyecto")
    public ResponseEntity<?> create(@RequestBody ProyectoDto proyectoDto){

        if(StringUtils.isBlank(proyectoDto.getNombre()))
            return new ResponseEntity(new Mensaje("el nombre es obligatorio"), HttpStatus.BAD_REQUEST);

        if(proyectoService.existsByNombre(proyectoDto.getNombre()))
            return new ResponseEntity(new Mensaje("ese nombre ya existe"), HttpStatus.BAD_REQUEST);

        //controlar los campos faltantes que no estoy controlando

        //tomo el dato del constructor de la clase entity Experiencia
        Proyecto proyecto = new Proyecto(proyectoDto.getNombre(),proyectoDto.getFecha(),proyectoDto.getDescripcion(),proyectoDto.getLink());

        proyectoService.save(proyecto);

        return new ResponseEntity(new Mensaje("Proyecto creado"), HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/update-proyecto/{id}")
    public ResponseEntity<?> update(@PathVariable("id")int id, @RequestBody ProyectoDto proyectoDto){
        if(!proyectoService.existsById(id))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);

        if(proyectoService.existsByNombre(proyectoDto.getNombre()) && proyectoService.getByNombre(proyectoDto.getNombre()).get().getId() != id)
            return new ResponseEntity(new Mensaje("el nombre ya existe"), HttpStatus.BAD_REQUEST);

        if(StringUtils.isBlank(proyectoDto.getNombre()))
            return new ResponseEntity(new Mensaje("el nombre es obligatorio"), HttpStatus.BAD_REQUEST);

        //falta validar PUESTO Y DESCRIPCION

        Proyecto proyecto = proyectoService.getOne(id).get();

        proyecto.setNombre(proyectoDto.getNombre());

        proyecto.setFecha(proyectoDto.getFecha());

        proyecto.setDescripcion(proyectoDto.getDescripcion());

        proyecto.setLink(proyectoDto.getLink());


        proyectoService.save(proyecto);

        return new ResponseEntity(new Mensaje("proyecto actualizado"), HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/delete-proyecto/{id}")
    public ResponseEntity<?> delete(@PathVariable("id")int id){
        if(!proyectoService.existsById(id))
            return new ResponseEntity(new Mensaje("no existe"), HttpStatus.NOT_FOUND);
        proyectoService.delete(id);
        return new ResponseEntity(new Mensaje("Proyecto eliminado"), HttpStatus.OK);
    }


}
