package com.tutorial.crud.dto;


import javax.validation.constraints.NotBlank;

public class ExperienciaDto {

    @NotBlank
    private String empresa;

    @NotBlank
    private String puesto;

    @NotBlank
    private String descripcion;

    public ExperienciaDto() {
    }

    public ExperienciaDto(String empresa, String puesto, String descripcion) {
        this.empresa = empresa;
        this.puesto = puesto;
        this.descripcion = descripcion;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
