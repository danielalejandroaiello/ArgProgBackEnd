package com.tutorial.crud.dto;


import javax.validation.constraints.NotBlank;

public class EducacionDto {


    @NotBlank
    private String titulo;

    @NotBlank
    private String instituto;

    @NotBlank
    private String fechaInicioFin;

    @NotBlank
    private String descripcion;

    public EducacionDto() {
    }

    public EducacionDto(String titulo, String instituto, String fechaInicioFin, String descripcion) {
        this.titulo = titulo;
        this.instituto = instituto;
        this.fechaInicioFin = fechaInicioFin;
        this.descripcion = descripcion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getInstituto() {
        return instituto;
    }

    public void setInstituto(String instituto) {
        this.instituto = instituto;
    }

    public String getFechaInicioFin() {
        return fechaInicioFin;
    }

    public void setFechaInicioFin(String fechaInicioFin) {
        this.fechaInicioFin = fechaInicioFin;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

}
